/**
 * James Grieder
 * ARSLab - Carleton University
 * August 2023
 *
 * An atomic DEVS model for the Embedded Cadmium IO_Testing_Digital example on the
 * MSP432P401R Microcontroller used with the Educational Boosterpack MK II.  This
 * example demonstrates how to use digital inputs and outputs in Embedded Cadmium.
 *
 * The MSP432 Red LED, RGB and the Boosterpack RGB all begin toggling to the next
 * state every 5 seconds.  The Red LED will toggle on and off, and both of the RGBs
 * will toggle the states as follows: Red, Green, Blue, Off.
 *
 * Using any of the inputs below will change the toggling speed accordingly:
 *
 * MSP432 Switch 1.1 - 5.0 seconds
 * MSP432 Switch 1.4 - 3.0 seconds
 * Boosterpack Top Button - 1.5 seconds
 * Boosterpack Bottom Button - 0.75 seconds
 * Boosterpack Gator Hole - 0.3 seconds
 * Boosterpack Joystick Button - 0.1 seconds
 */

#ifndef __DIGITAL_IO_CONTROLLER_HPP__
#define __DIGITAL_IO_CONTROLLER_HPP__

// This is an atomic model, meaning it has its' own internal logic/computation
// So, it is necessary to include atomic.hpp
#include <modeling/devs/atomic.hpp>

#if !defined NO_LOGGING || !defined EMBED
#include <iostream>
#endif

namespace cadmium::digitalIOSystem {
    // A class to represent the state of this specific model
    // All atomic models will have their own state
    struct DigitalIOControllerState {

        // sigma is a mandatory variable for atomic models, used to advance the time of the simulation
        double sigma;

        // Declare model-specific variables

        int toggleSpeed;    // A counter for the toggling speed of the program

        int rgbCounter;     // A counter for the next RGB states

        bool mspLedOn;      // We will use one variable for each LED on the MSP432 & Boosterpack MK II

        bool mspRedOn;
        bool mspGreenOn;
        bool mspBlueOn;

        bool bspRedOn;
        bool bspGreenOn;
        bool bspBlueOn;


        // Set the default values for the state constructor for this specific model
        DigitalIOControllerState(): sigma(0), toggleSpeed(0), rgbCounter(0), mspLedOn(false), mspRedOn(false), mspGreenOn(false), mspBlueOn(false), bspRedOn(false), bspGreenOn(false), bspBlueOn(false) {}
    };

#if !defined NO_LOGGING || !defined EMBED 
    /**
     * This function is used to output the current state of the model to the .csv output
     * file after each internal transition.  This is used to verify the accuracy of the
     * simulation.
     *
     * In this model, each time the internal transition function is invoked the current
     * output from the out port is listed, followed by the model's current state for
     * state.lightOn, and state.sigma.
     *
     * Note that state.sigma is NOT mandatory to include here, but it is listed due to
     * its significance in the program.
     *
     * @param out output stream.
     * @param s state to be represented in the output stream.
     * @return output stream with state variables already inserted.
     */
    std::ostream& operator<<(std::ostream &out, const DigitalIOControllerState& state) {
        out << ", sigma: " << state.sigma << ", toggleSpeed: " << state.toggleSpeed << ", rgbCounter: " << state.rgbCounter << ", mspLedOn: " << state.mspLedOn << ", mspRedOn: " << state.mspRedOn << ", mspGreenOn: " << state.mspGreenOn << ", mspBlueOn: " << state.mspBlueOn << ", bspRedOn: " << state.bspBlueOn << ", bspGreenOn: " << state.bspGreenOn;
        return out;
    }
#endif

    // Atomic DEVS model of DigitalIOController
    class DigitalIOController : public Atomic<DigitalIOControllerState> {
    private:

    public:

        // Declare ports for the model
        // Input ports
        Port<bool> inMspSwitch1;
        Port<bool> inMspSwitch2;

        Port<bool> inBspSwitch1;
        Port<bool> inBspSwitch2;

        Port<bool> inBspGator;

        Port<bool> inJoystick;

        // Output ports
        Port<bool> outMspLED;

        Port<bool> outMspRed;
        Port<bool> outMspGreen;
        Port<bool> outMspBlue;

        Port<bool> outBspRed;
        Port<bool> outBspGreen;
        Port<bool> outBspBlue;


        // Declare variables for the model's behaviour
        double extraSlowToggleTime;
        double slowToggleTime;
        double mediumToggleTime;
        double fastToggleTime;
        double extraFastToggleTime;
        double maxToggleTime;

        /**
         * Constructor function for this atomic model, and its respective state object.
         *
         * For this model, both a DigitalIOController object and a DigitalIOControllerState object
         * are created, using the same id.
         *
         * @param id ID of the new DigitalIOController model object, will be used to identify results on the output file
         */
        DigitalIOController(const std::string& id): Atomic<DigitalIOControllerState>(id, DigitalIOControllerState()) {

            // Initialize ports for the model

            // Input ports
            inMspSwitch1 = addInPort<bool>("inMspSwitch1");
            inMspSwitch2 = addInPort<bool>("inMspSwitch2");

            inBspSwitch1 = addInPort<bool>("inBspSwitch1");
            inBspSwitch2 = addInPort<bool>("inBspSwitch2");

            inBspGator = addInPort<bool>("inBspGators");

            inJoystick = addInPort<bool>("inJoystick");

            // Output ports
            outMspLED = addOutPort<bool>("outMspLED");

            outMspRed = addOutPort<bool>("outMspRed");
            outMspGreen = addOutPort<bool>("outMspGreen");
            outMspBlue = addOutPort<bool>("outMspBlue");

            outBspRed = addOutPort<bool>("outBspRed");
            outBspGreen = addOutPort<bool>("outBspGreen");
            outBspBlue = addOutPort<bool>("outBspBlue");


            // Initialize variables for the model's behaviour
            extraSlowToggleTime = 5.0;      // mspSwitch1
            slowToggleTime = 3.0;           // mspSwitch2
            mediumToggleTime = 1.5;         // bspSwitch1
            fastToggleTime = 0.75;          // bspSwitch2
            extraFastToggleTime = 0.3;      // gator hole input
            maxToggleTime = 0.1;            // joystick select


            // Set a value for sigma (so it is not 0), this determines how often the
            // internal transition occurs
            state.toggleSpeed = 0;
            state.sigma = extraSlowToggleTime;

        }

        /**
         * The transition function is invoked each time the value of
         * state.sigma reaches 0.
         *
         * In this model, the MSP432's red LED will toggle on and off
         * with each invocation.  The MSP432's RGB and the Boosterpack
         * RGB will cycle through states in the following order:
         * Red, Green, Blue, off.
         *
         * @param state reference to the current state of the model.
         */
        void internalTransition(DigitalIOControllerState& state) const override {

            // Toggle the red LED's state
            state.mspLedOn = !state.mspLedOn;

            // Increment the RGB Counter, and update the RGB states accordingly
            state.rgbCounter++;
            state.rgbCounter %= 4;

            switch (state.rgbCounter) {

            case 0:
                state.mspRedOn = false;
                state.mspGreenOn = false;
                state.mspBlueOn = false;
                state.bspRedOn = false;
                state.bspGreenOn = false;
                state.bspBlueOn = false;
                break;

            case 1:
                state.mspRedOn = true;
                state.mspGreenOn = false;
                state.mspBlueOn = false;
                state.bspRedOn = true;
                state.bspGreenOn = false;
                state.bspBlueOn = false;
                break;

            case 2:
                state.mspRedOn = false;
                state.mspGreenOn = true;
                state.mspBlueOn = false;
                state.bspRedOn = false;
                state.bspGreenOn = true;
                state.bspBlueOn = false;
                break;

            case 3:
                state.mspRedOn = false;
                state.mspGreenOn = false;
                state.mspBlueOn = true;
                state.bspRedOn = false;
                state.bspGreenOn = false;
                state.bspBlueOn = true;
                break;
            }
        }

        /**
         * The external transition function is invoked each time external data
         * is sent to an input port for this model.
         *
         * In this model, the value of state.sigma is updated to a new value
         * depending on the button pressed, as follows:
         *
         * MSP432 Switch 1.1 --> 5.0 seconds
         * MSP432 Switch 1.4 --> 3.0 seconds
         * Boosterpack top button --> 1.0 seconds
         * Boosterpack bottom button --> 0.75 seconds
         * Gator hole --> 0.30 seconds
         * Joystick button --> 0.10 seconds
         *
         * These values indicate how often the internal transition function is invoked.
         *
         * @param state reference to the current model state.
         * @param e time elapsed since the last state transition function was triggered.
         */
        void externalTransition(DigitalIOControllerState& state, double e) const override {

            // First check if there are un-handled inputs for mspSwitch1
            if(!inMspSwitch1->empty()){

                // The variable x is created to handle the external input values in sequence.
                // The getBag() function is used to get the next input value.
                for( const auto x : inMspSwitch1->getBag()){
                    if (x==0) {
                        state.toggleSpeed = 0;  // if the button was pressed, we update the state of our model to have a toggleSpeed of 0
                    }
                }
            }

            // We then repeat the process of checking for un-handled inputs, getting the next value,
            // and updating the toggleSpeed (if applicable) for all inputs.
            if(!inMspSwitch2->empty()){
                for( const auto x : inMspSwitch2->getBag()){
                    if (x==0) {
                        state.toggleSpeed = 1;
                    }
                }
            }

            if(!inBspSwitch1->empty()){
                for( const auto x : inBspSwitch1->getBag()){
                    if (x==0) {
                        state.toggleSpeed = 2;
                    }
                }
            }

            if(!inBspSwitch2->empty()){
                for( const auto x : inBspSwitch2->getBag()){
                    if (x==0) {
                        state.toggleSpeed = 3;
                    }
                }
            }
            if(!inBspGator->empty()){
                for( const auto x : inBspGator->getBag()){
                    if (x==0) {
                        state.toggleSpeed = 4;
                    }
                }
            }

            if(!inJoystick->empty()){
                for( const auto x : inJoystick->getBag()){
                    if (x==0) {
                        state.toggleSpeed = 5;
                    }
                }
            }


            // Next, we set a new value for sigma based on the toggleSpeed
            switch (state.toggleSpeed) {
            case 0:
                state.sigma = extraSlowToggleTime;
                break;

            case 1:
                state.sigma = slowToggleTime;
                break;

            case 2:
                state.sigma = mediumToggleTime;
                break;

            case 3:
                state.sigma = fastToggleTime;
                break;

            case 4:
                state.sigma = extraFastToggleTime;
                break;

            case 5:
                state.sigma = maxToggleTime;
                break;
            }

        }

        /**
         * This function outputs any desired state values to their associated ports.
         *
         * In this model, we send the state value corresponding to each LED to the
         * associated output port of this controller model.  Once that value reaches
         * the I/O model (digitalOutput), that model will update the status of the LED.
         *
         * @param state reference to the current model state.
         */
        void output(const DigitalIOControllerState& state) const override {

            outMspLED->addMessage(state.mspLedOn);

            outMspRed->addMessage(state.mspRedOn);
            outMspGreen->addMessage(state.mspGreenOn);
            outMspBlue->addMessage(state.mspBlueOn);

            outBspRed->addMessage(state.bspRedOn);
            outBspGreen->addMessage(state.bspGreenOn);
            outBspBlue->addMessage(state.bspBlueOn);

        }

        /**
         * Returns the value of state.sigma for this model.
         *
         * This function is the same for all models, and does not need to be changed.
         *
         * @param state reference to the current model state.
         * @return the sigma value.
         */
        [[nodiscard]] double timeAdvance(const DigitalIOControllerState& state) const override {

            return state.sigma;

        }
    };
} // namespace cadmium::DigitalIOSystem

#endif // __DIGITAL_IO_CONTROLLER_HPP__
