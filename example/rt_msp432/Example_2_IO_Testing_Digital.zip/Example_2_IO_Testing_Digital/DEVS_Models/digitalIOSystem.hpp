/**
 * James Grieder
 * ARSLab - Carleton University
 * August 2023
 *
 * A coupled DEVS model for the Embedded Cadmium IO_Testing_Digital example on the
 * MSP432P401R Microcontroller used with the Educational Boosterpack MK II.  This
 * example demonstrates how to use digital inputs and outputs in Embedded Cadmium.
 *
 * digitalIOSystem is the top model for this example.  It contains the
 * digitalIOController atomic model, and connects the controller to IO Models
 * (digitalInput, digitalOutput) as defined in the IO_Models folder.
 *
 * The MSP432 Red LED, RGB and the Boosterpack RGB all begin toggling to the next
 * state every 5 seconds.  Using any of the built-in digital inputs on the MSP432
 * or the Boosterpack will change the time interval from 5 seconds to another value.
 */

#ifndef __DIGITAL_IO_SYSTEM_HPP__
#define __DIGITAL_IO_SYSTEM_HPP__

// This is a coupled model, meaning it has no internal computation, and is
// used to connect atomic models.  So, it is necessary to include coupled.hpp
#include <modeling/devs/coupled.hpp>

#ifdef EMBED
    #include "../../IO_Models/accelerometerInput.hpp"
    #include "../../IO_Models/digitalInput.hpp"
    #include "../../IO_Models/digitalOutput.hpp"
    #include "../../IO_Models/joystickInput.hpp"
    #include "../../IO_Models/lcdOutput.hpp"
    #include "../../IO_Models/lightSensorInput.hpp"
    #include "../../IO_Models/microphoneInput.hpp"
    #include "../../IO_Models/pwmOutput.hpp"
    #include "../../IO_Models/temperatureSensorInput.hpp"
#else
    #include <lib/iestream.hpp>
#endif

// We include any models that are directly contained within this coupled model
#include <digitalIOController.hpp>

namespace cadmium::digitalIOSystem {
    class DigitalIOSystem : public Coupled {
        public:
        DigitalIOSystem(const std::string& id): Coupled(id){

            // Declare and initialize all controller models (non-input/output)
            auto digitalIOController = addComponent<DigitalIOController>("digitalIOController");

            // Connect any non-input/output models with coupling
            // (NOT APPLICABLE FOR THIS MODEL)

        #ifdef EMBED

            // Declare and initialize all embedded input/output models

            // Digital Inputs
            auto mspSwitch1 = addComponent<DigitalInput>("mspSwitch1",GPIO_PORT_P1,GPIO_PIN1); // MSP432 Switch 1.1 (left side with plug at top)
            auto mspSwitch2 = addComponent<DigitalInput>("mspSwitch2",GPIO_PORT_P1,GPIO_PIN4); // MSP432 Switch 1.4 (right side with plug at top)

            auto bspSwitch1 = addComponent<DigitalInput>("bspSwitch1",GPIO_PORT_P5,GPIO_PIN1); // Boosterpack top switch
            auto bspSwitch2 = addComponent<DigitalInput>("bspSwitch2",GPIO_PORT_P3,GPIO_PIN5); // Boosterpack bottom switch

            auto bspGator = addComponent<DigitalInput>("bspGator",GPIO_PORT_P2,GPIO_PIN3); // Boosterpack gator hole

            auto joystickButton = addComponent<DigitalInput>("joystickButton", GPIO_PORT_P4,GPIO_PIN1); // Boosterpack joystick button

            // Digital Outputs
            auto mspLED = addComponent<DigitalOutput>("mspLED",GPIO_PORT_P1,GPIO_PIN0); // MSP432 Red LED

            auto mspRed = addComponent<DigitalOutput>("mspRed",GPIO_PORT_P2,GPIO_PIN0); // MSP432 Red RGB
            auto mspGreen = addComponent<DigitalOutput>("mspGreen",GPIO_PORT_P2,GPIO_PIN1); // MSP432 Green RGB
            auto mspBlue = addComponent<DigitalOutput>("mspBlue",GPIO_PORT_P2,GPIO_PIN2); // MSP432 Blue RGB

            auto bspRed = addComponent<DigitalOutput>("bspRed",GPIO_PORT_P2,GPIO_PIN6); // Boosterpack Red RGB
            auto bspGreen = addComponent<DigitalOutput>("bspGreen",GPIO_PORT_P2,GPIO_PIN4); // Boosterpack Green RGB
            auto bspBlue = addComponent<DigitalOutput>("bspBlue",GPIO_PORT_P5,GPIO_PIN6); // Boosterpack Blue RGB

            // Connect IO models with coupling to the system
            // Inputs
            addCoupling(mspSwitch1->out,digitalIOController->inMspSwitch1);
            addCoupling(mspSwitch2->out,digitalIOController->inMspSwitch2);

            addCoupling(bspSwitch1->out,digitalIOController->inBspSwitch1);
            addCoupling(bspSwitch2->out,digitalIOController->inBspSwitch2);

            addCoupling(bspGator->out,digitalIOController->inBspGator);

            addCoupling(joystickButton->out,digitalIOController->inJoystick);

            // Outputs
            addCoupling(digitalIOController->outMspLED,mspLED->in);

            addCoupling(digitalIOController->outMspRed,mspRed->in);
            addCoupling(digitalIOController->outMspGreen,mspGreen->in);
            addCoupling(digitalIOController->outMspBlue,mspBlue->in);

            addCoupling(digitalIOController->outBspRed,bspRed->in);
            addCoupling(digitalIOController->outBspGreen,bspGreen->in);
            addCoupling(digitalIOController->outBspBlue,bspBlue->in);

        #else

            // Declare and initialize all simulated input files (these must exist in the file system before compilation)
            auto mspSwitch1Input = addComponent<cadmium::lib::IEStream<bool>>("mspSwitch1Input","mspSwitch1Input.txt");
            auto mspSwitch2Input = addComponent<cadmium::lib::IEStream<bool>>("mspSwitch2Input","mspSwitch2Input.txt");
            auto bspSwitch1Input = addComponent<cadmium::lib::IEStream<bool>>("bspSwitch1Input","bspSwitch1Input.txt");
            auto bspSwitch2Input = addComponent<cadmium::lib::IEStream<bool>>("bspSwitch2Input","bspSwitch2Input.txt");
            auto bspGatorInput = addComponent<cadmium::lib::IEStream<bool>>("bspGatorInput","bspGatorInput.txt");
            auto joystickInput = addComponent<cadmium::lib::IEStream<bool>>("joystickInput","joystickInput.txt");

            // Connect the input files to the rest of the simulation with coupling
            addCoupling(mspSwitch1Input->out,digitalIOController->inMspSwitch1);
            addCoupling(mspSwitch2Input->out,digitalIOController->inMspSwitch2);
            addCoupling(bspSwitch1Input->out,digitalIOController->inBspSwitch1);
            addCoupling(bspSwitch2Input->out,digitalIOController->inBspSwitch2);
            addCoupling(bspGatorInput->out,digitalIOController->inBspGator);
            addCoupling(joystickInput->out,digitalIOController->inJoystick);

        #endif
        }
    };
} // namespace cadmium::digitalIOSystem

#endif // __DIGITAL_IO_SYSTEM_HPP__
