/**
 * James Grieder
 * ARSLab - Carleton University
 * August 2023
 *
 * A coupled DEVS model for the Embedded Cadmium IO_Testing_Analog example on the
 * MSP432P401R Microcontroller used with the Educational Boosterpack MK II.  This
 * example demonstrates how to use a variety of inputs and outputs in Embedded Cadmium.
 *
 * analogIOSystem is the top model for this example.  It contains the
 * analogIOController atomic model, and connects the controller to IO Models
 * (accelerometerInput, digitalInput, digitalOutput, joystickInput, lcdOutput,
 * microphoneInput, and pwmOutput) as defined in the IO_Models folder.
 *
 * The top button on the Boosterpack is used to cycle between input/output modes, which
 * are then displayed on the LCD screen.  The user can use the specified input to trigger
 * an output on the hardware.
 */

#ifndef __ANALOG_IO_SYSTEM_HPP__
#define __ANALOG_IO_SYSTEM_HPP__

// This is a coupled model, meaning it has no internal computation, and is
// used to connect atomic models.  So, it is necessary to include coupled.hpp
#include <modeling/devs/coupled.hpp>

#ifdef EMBED
    #include "../../IO_Models/accelerometerInput.hpp"
    #include "../../IO_Models/digitalInput.hpp"
    #include "../../IO_Models/digitalOutput.hpp"
    #include "../../IO_Models/joystickInput.hpp"
    #include "../../IO_Models/lcdOutput.hpp"
    #include "../../IO_Models/lightSensorInput.hpp"
    #include "../../IO_Models/microphoneInput.hpp"
    #include "../../IO_Models/pwmOutput.hpp"
    #include "../../IO_Models/temperatureSensorInput.hpp"
#else
    #include <lib/iestream.hpp>
#endif

// We include any models that are directly contained within this coupled model
#include <analogIOController.hpp>

namespace cadmium::analogIOSystem {
    class AnalogIOSystem : public Coupled {
    public:
        AnalogIOSystem(const std::string& id): Coupled(id){

            // Declare and initialize all controller models (non-input/output)
            auto ioswitch = addComponent<AnalogIOController>("ioswitch");

            // Connect any non-input/output models with coupling
            // (NOT APPLICABLE FOR THIS MODEL)

#ifdef EMBED

            // Declare and initialize all embedded input/output models

            // Digital inputs
            auto modeToggle = addComponent<DigitalInput>("modeToggle",GPIO_PORT_P5,GPIO_PIN1);
            auto lowerButtonInput = addComponent<DigitalInput>("lowerButton",GPIO_PORT_P3,GPIO_PIN5);
            auto gatorHoleInput = addComponent<DigitalInput>("gatorHole",GPIO_PORT_P2,GPIO_PIN3);

            // Analog inputs
            auto microphoneInput = addComponent<MicrophoneInput>("microphoneInput");
            auto joystickInput = addComponent<JoystickInput>("joystickInput");
            auto accelerometerInput = addComponent<AccelerometerInput>("accelerometerInput");

            // Digital outputs
            auto digitalRed = addComponent<DigitalOutput>("digitalOutput",GPIO_PORT_P1,GPIO_PIN0);
            auto digitalGreen = addComponent<DigitalOutput>("digitalGreen",GPIO_PORT_P2,GPIO_PIN1);

            // LCD Outputs
            auto lcdOutput1 = addComponent<LCDOutput>("lcdOutput1");
            auto lcdOutput2 = addComponent<LCDOutput>("lcdOutput2");
            auto lcdOutput3 = addComponent<LCDOutput>("lcdOutput3");
            auto lcdOutput4 = addComponent<LCDOutput>("lcdOutput4");

            // PWMOutputs
            auto buzzerOutput = addComponent<PWMOutput>("buzzerOutput",GPIO_PORT_P2,GPIO_PIN7);
            auto pwmRed = addComponent<PWMOutput>("pwmRed",GPIO_PORT_P2,GPIO_PIN6);
            auto pwmGreen = addComponent<PWMOutput>("pwmGreen",GPIO_PORT_P2,GPIO_PIN4);
            auto pwmBlue = addComponent<PWMOutput>("pwmBlue",GPIO_PORT_P5,GPIO_PIN6);


            // Connect IO models with coupling to the system

            // Digital inputs
            addCoupling(modeToggle->out,ioswitch->inModeToggle);
            addCoupling(lowerButtonInput->out,ioswitch->inLowerButton);
            addCoupling(gatorHoleInput->out,ioswitch->inGatorHole);

            // Analog inputs
            addCoupling(microphoneInput->out,ioswitch->inMicrophone);

            addCoupling(joystickInput->outX,ioswitch->inJoystickX);
            addCoupling(joystickInput->outY,ioswitch->inJoystickY);
            addCoupling(joystickInput->outSelect,ioswitch->inJoystickSelect);

            addCoupling(accelerometerInput->outX,ioswitch->inAccelerometerX);
            addCoupling(accelerometerInput->outY,ioswitch->inAccelerometerY);
            addCoupling(accelerometerInput->outZ,ioswitch->inAccelerometerZ);

            // Digital outputs
            addCoupling(ioswitch->outDigitalRed,digitalRed->in);
            addCoupling(ioswitch->outDigitalGreen,digitalGreen->in);

            // LCD Outputs
            addCoupling(ioswitch->lcdMode,lcdOutput1->in);
            addCoupling(ioswitch->lcdInputText,lcdOutput2->in);
            addCoupling(ioswitch->lcdOutputText,lcdOutput3->in);
            addCoupling(ioswitch->lcdOut,lcdOutput4->in);

            // PWMOutputs
            addCoupling(ioswitch->outBuzzer,buzzerOutput->in);
            addCoupling(ioswitch->outPWMRed,pwmRed->in);
            addCoupling(ioswitch->outPWMGreen,pwmGreen->in);
            addCoupling(ioswitch->outPWMBlue,pwmBlue->in);


#else

            // Declare and initialize all simulated input files (these must exist in the file system before compilation)
            auto modeToggleInput = addComponent<cadmium::lib::IEStream<bool>>("modeToggleInput","modeToggleInput.txt");
            auto lowerButtonInput = addComponent<cadmium::lib::IEStream<bool>>("lowerButtonInput","lowerButtonInput.txt");
            auto gatorHoleInput = addComponent<cadmium::lib::IEStream<bool>>("gatorHoleInput","gatorHoleInput.txt");

            auto microphoneInput = addComponent<cadmium::lib::IEStream<int>>("microphoneInput","microphoneInput.txt");

            auto joystickXInput = addComponent<cadmium::lib::IEStream<int>>("joystickXInput","joystickXInput.txt");
            auto joystickYInput = addComponent<cadmium::lib::IEStream<int>>("joystickYInput","joystickYInput.txt");
            auto joystickSelectInput = addComponent<cadmium::lib::IEStream<bool>>("joystickSelectInput","joystickSelectInput.txt");

            auto accelerometerXInput = addComponent<cadmium::lib::IEStream<int>>("accelerometerXInput","accelerometerXInput.txt");
            auto accelerometerYInput = addComponent<cadmium::lib::IEStream<int>>("accelerometerYInput","accelerometerYInput.txt");
            auto accelerometerZInput = addComponent<cadmium::lib::IEStream<int>>("accelerometerZInput","accelerometerZInput.txt");

            // Connect the input files to the rest of the simulation with coupling
            addCoupling(modeToggleInput->out,ioswitch->inModeToggle);
            addCoupling(lowerButtonInput->out,ioswitch->inLowerButton);
            addCoupling(gatorHoleInput->out,ioswitch->inGatorHole);

            addCoupling(microphoneInput->out,ioswitch->inMicrophone);

            addCoupling(joystickXInput->out,ioswitch->inJoystickX);
            addCoupling(joystickYInput->out,ioswitch->inJoystickY);
            addCoupling(joystickSelectInput->out,ioswitch->inJoystickSelect);

            addCoupling(accelerometerXInput->out,ioswitch->inAccelerometerX);
            addCoupling(accelerometerYInput->out,ioswitch->inAccelerometerY);
            addCoupling(accelerometerZInput->out,ioswitch->inAccelerometerZ);

#endif
        }
    };
} // namespace cadmium::analogIOSystem

#endif // __ANALOG_IO_SYSTEM_HPP__
