#ifndef __TEMPLATEATOMIC_HPP__
#define __TEMPLATEATOMIC_HPP__

// This is an atomic model, meaning it has its' own internal logic/computation
// So, it is necessary to include atomic.hpp
#include <modeling/devs/atomic.hpp>

#if !defined NO_LOGGING || !defined EMBED
    #include <iostream>
#endif

namespace cadmium::templateCoupled {
    // A class to represent the state of this specific model
    // All atomic models will have their own state
    struct TemplateAtomicState {

        // sigma is a mandatory variable, used to advance the time of the simulation
        double sigma;

        // Declare model-specific variables


        // Set the default values for the state constructor for this specific model
        TemplateAtomicState(): sigma(0)  {}
    };

#if !defined NO_LOGGING || !defined EMBED 
    /**
     * This function is used to output the current state of the model to the .csv output
     * file after each internal transition.  This is used to verify the accuracy of the
     * simulation.
     *
     * @param out output stream.
     * @param s state to be represented in the output stream.
     * @return output stream with sigma and lightOn already inserted.
     */
    std::ostream& operator<<(std::ostream &out, const TemplateAtomicState& state) {


        return out;
    }
#endif

    // Atomic model of TemplateAtomic
    class TemplateAtomic : public Atomic<TemplateAtomicState> {
     private:

     public:

        // Declare ports for the model

        // Input ports


        // Output ports


        // Declare variables for the model's behaviour



        /**
         * Constructor function for this atomic model, and its respective state object.
         *
         * @param id ID of the new Blinky model object, will be used to identify results on the output file
         */
        TemplateAtomic(const std::string& id): Atomic<TemplateAtomicState>(id, TemplateAtomicState()) {

            // Initialize ports for the model

            // Input ports


            // Output ports


            // Initialize variables for the model's behaviour



            // Set a value for sigma (so it is not 0), this determines how often the
            // internal transition occurs


        }

        /**
         * The transition function is invoked each time the value of
         * state.sigma reaches 0.
         *
         * @param state reference to the current state of the model.
         */
        void internalTransition(TemplateAtomicState& state) const override {

            // Internal transition behaviour may update one or more desired state variables

        }

        /**
         * The external transition function is invoked each time external data
         * is sent to an input port for this model.
         *
         * @param state reference to the current model state.
         * @param e time elapsed since the last state transition function was triggered.
         */
        void externalTransition(TemplateAtomicState& state, double e) const override {

            // Similar to internal transitions, external transitions may also update state variables

            // First check if there are un-handled inputs


                // The variable x is created to handle the external input values in sequence.
                // The getBag() function is used to get the next input value.


                    // Behaviour logic for each input goes here
                    // if statements may be useful to filter out undesired inputs






        }

        /**
         * This function outputs any desired state values to their associated ports.
         *
         * @param state reference to the current model state.
         */
        void output(const TemplateAtomicState& state) const override {

            // The following notation will output variableName via portName
            // portName->addMessage(state.variableName);


        }

        /**
         * It returns the value of state.sigma for this model.
         *
         * This function is the same for all models, and does not need to be changed.
         *
         * @param state reference to the current model state.
         * @return the sigma value.
         */
        [[nodiscard]] double timeAdvance(const TemplateAtomicState& state) const override {

            return state.sigma;

        }
    };
} // namespace cadmium::templateCoupled

#endif // __TEMPLATEATOMIC_HPP__
